"""Backtesting and validation helpers."""
